public class ifelsee {
    public static void main(String[] args) {
        // variable declaration
        int a=48;
        //to check a is even or odd
        if(a % 2 == 0) {
            System.out.println("a is even");
        } else {
            System.out.println("a is odd");
        }
    }
}
 