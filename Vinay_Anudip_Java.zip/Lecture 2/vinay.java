
public class vinay {
    public static void main(String[] args) {
        int age =  2147483647;      
        double marks = 85.5;
        char grade = 'A';
        boolean passed = true;
        String name = "Vinay";

        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Marks: " + marks);
        System.out.println("Grade: " + grade);
        System.out.println("Passed: " + passed);
    }
}

