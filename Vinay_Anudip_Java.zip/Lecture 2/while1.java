public class while1{
    public static void main(String[] args){
    int i = 6;
    while (i < 5){
    System.out.println("Hello");
    i++;
} 
}
}
