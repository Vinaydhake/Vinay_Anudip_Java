public class do_while{
    
    //A loop is used to repeat a block of code multiple times.
    //The condition is checked after the loop body runs.
    // code runs at least one time, even if the condition is false.
    public static void main(String[] args){
    int i = 2;
        do {
              System.out.println("Hello");
              i++;
            } while (i < 5);

       }
}