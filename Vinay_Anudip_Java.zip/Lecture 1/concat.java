public class concat{
    public static void main(String[] args){

String a="Vinay";
String b="dhake";
String c;
c=a+b; //concatenation
System.out.println("The value of c is: " + c);
}
}