public class Ternary {
    public static void main(String[] args) {
    int daysInFebruary = 28;
    String result;
    // ternary operator
    result = (daysInFebruary == 28) ? "Not a leap year" : "Leap year";
    
   
    System.out.println(result);
    }
   }
    
   