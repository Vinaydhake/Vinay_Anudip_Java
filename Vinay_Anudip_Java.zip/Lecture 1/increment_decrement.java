public class increment_decrement {
    public static void main(String[] args){
        int a = 300;
        int b = 200;

        if(a<b){
            a++;
            System.out.println("a : "+a);
        }
        else{
            b--;
            System.out.println("b : "+b);
        }
}
}
