public class Relational {
    public static void main(String[] args){
        int a = 10;
        int b = 20;

        if(a<=b){
            System.out.println("b is greater");
        }
        else{
            System.out.println("a is less or equal to b");
        }
}
}