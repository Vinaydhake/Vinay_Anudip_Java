public class Arithematic {
    public static void main(String[] args){
        int a = 202;
        int b = 20;
        int moduloo;
        
        moduloo = a % b;

        System.out.println("a % b="+moduloo);

}
}
