public class ternery_for_even_odd {
    public static void main(String[] args){
    int num = 28;
    String result;
    // ternary operator
    result = (num%2==0) ? "even" : "odd";
    
   
    System.out.println(result);
        
}
}
