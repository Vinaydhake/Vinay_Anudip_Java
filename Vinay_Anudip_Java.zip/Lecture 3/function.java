public class function {
    
    public static float moduloo(float a ,float b){
        return a % b;
    }

    public static void main(String[] args){
    float remainder;
        remainder = moduloo(10.0f,5.0f);
        System.out.println("Remainder is " + remainder);
}
}
