public class math_function {
    public static void main(String[] args) {
    System.out.println("Max is " +Math.max(10, 20));
    System.out.println("Min is " +Math.min(10, 20));
    System.out.println("Squareroot is " +Math.sqrt(25));        
    System.out.println("Exponent is " +Math.pow(2, 3));
    System.out.println("Absolute value is " +Math.abs(-7));           
    System.out.println("Random number " +Math.random());          



}
}
