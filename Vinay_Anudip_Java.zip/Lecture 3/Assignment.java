public class Assignment {
    public static void main(String[] args){
        int a = 10;
        int b = 20;
        int add,sub,mult,div;
        add = a+b;
        sub = a-b;
        mult = a*b;
        div = a/b;

        System.out.println("a + b="+add);
        System.out.println("a - b="+sub);
        System.out.println("a * b="+mult);
        System.out.println("a / b="+div);

}
}
